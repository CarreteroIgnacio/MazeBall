﻿using Unity.Mathematics;
using UnityEngine;

namespace Plugins.Extensions
{
    public static class Float4x4
    {

        public static float3 GetPosition(this float4x4 value)
            => new(value.c3.x,value.c3.y,value.c3.z);

        
        /// <summary> <para>Set the position of the matrix.</para> </summary>
        public static void SetPosition(this ref float4x4 matrix, float3 value)
            => matrix.c3 = new float4(value.x, value.y, value.z, 1);
        
        /// <summary> <para>Return a copy of the matrix with the position set as.</para> </summary>
        public static float4x4 WithPositionSet(this float4x4 matrix, float3 position)
        {
            matrix.SetPosition(position);
            return matrix;
        }



        /// <summary> <para>Returns an Identity matrix with the position set.</para> </summary>
        public static float4x4 IdentityWithPosition(float3 position)
        {
            var matrix = float4x4.identity;
            return matrix.WithPositionSet(position);
        }
        
        
        public static float3 MultiplyVector(this ref float4x4 matrix, float3 vector)
        {
            return new float3(
                (matrix.c0.x * vector.x + matrix.c1.x * vector.y + matrix.c2.x * vector.z),
                (matrix.c0.y * vector.x + matrix.c1.y * vector.y + matrix.c2.y * vector.z),
                (matrix.c0.z * vector.x + matrix.c1.z * vector.y + matrix.c2.z* vector.z)
            );
        }
    }
}