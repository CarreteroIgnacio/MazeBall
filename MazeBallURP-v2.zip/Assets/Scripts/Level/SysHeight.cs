using Unity.Entities;


namespace Path
{
    [UpdateInGroup(typeof(FixedStepSimulationSystemGroup))]
    public partial class SysHeight : SystemBase
    {
        #region Events Functions

            protected override void OnCreate() { }

            protected override void OnStartRunning() { }

            protected override void OnUpdate() { }

        #endregion
    }
}