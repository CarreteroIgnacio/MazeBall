using CCC;
using Path;
using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Entities.Graphics;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Physics;
using Unity.Physics.Authoring;
using Unity.Rendering;
using Unity.Transforms;
using UnityEngine;

using RaycastHit = UnityEngine.RaycastHit;


namespace Level
{
    //[UpdateInGroup(typeof(FixedStepSimulationSystemGroup))]
    public partial class SysGridMaker : SystemBase
    {

        public static SysGridMaker Instance;

        private static MaterialMeshInfo _materialMeshInfoLod0;
        private static MaterialMeshInfo _materialMeshInfoLod1;
        private static PhysicsCollider _flatCollider;
        private static PhysicsCollider _rampCollider;

        
        
        
        #region Internals Vars

            private static int _index;
            private float _currentTime;
            private static GridMakerComponent _gridMakerComponent;
            private static float _timeRunning;
            private const float GridOffset = 0;
            private NativeList<Entity> _allEntities;
            private static Vector3 _startPos;
            private Entity _prefabEntity;
            private bool _validStart;
            private bool _alreadyStarted;
            
        #endregion


        private LoDData LoDBakeData;
        private struct LoDData
        {
            public MaterialMeshInfo MeshInfoDownLod0;
            public PhysicsCollider ColliderDownLod0;
            
            public MaterialMeshInfo MeshInfoDownLod1;
            public PhysicsCollider ColliderDownLod1;
            
            public MaterialMeshInfo MeshInfoUpLod0;
            public PhysicsCollider ColliderUpLod0;
            
            public MaterialMeshInfo MeshInfoUpLod1;
            public PhysicsCollider ColliderUpLod1;

            public MaterialMeshInfo MeshInfoUpLod2;
            public MaterialMeshInfo MeshInfoDownLod2;
        }

        #region Events Functions


            protected override void OnCreate() => Instance = this;

            protected override void OnStartRunning()
            {          
                if (!_validStart)
                {
                    Enabled = false;
                    return;
                }
                if(_alreadyStarted)return; // this is to be able to deactivate the system when pause the game
                
                
                if (CameraTrack.Instance is null)
                {
                    Debug.LogError("CameraTrack is Null");
                    Enabled = false;
                    return;
                }
                if (!SystemAPI.HasSingleton<PillarSpawnerComponent>())
                {
                    Debug.LogError("There is not PilarSpawnerComponent");
                    Enabled = false;
                    return;
                }
                if (!SystemAPI.HasSingleton<GridMakerComponent>())
                {
                    Debug.LogError("GridMakerComponent is Null");
                    Enabled = false;
                    return;
                }
                _gridMakerComponent = SystemAPI.GetSingleton<GridMakerComponent>();
                
                SetLodData();
                EntityCleanUp();
                
                
                _timeRunning = _gridMakerComponent.MapTransitionSpeed;
                var halfScale = _gridMakerComponent.GridScale / 2  - 0.5f;
                _startPos = _gridMakerComponent.LmPosition - new Vector3(halfScale, 0, halfScale);

                _allEntities = new NativeList<Entity>(64 * 64, Allocator.Persistent);
                for (var i = 0; i < _gridMakerComponent.CellAmount; i++)
                    for (var j = 0; j < _gridMakerComponent.CellAmount; j++)
                        PopulateCell(new Vector2Int(i, j), 64);

                
                UpdateDesiredHeight();
                EntityManager.DestroyEntity(_prefabEntity);
                
                
                
                new NativeList<RaycastCommand>( Allocator.Persistent);
                _result = new NativeArray<RaycastHit>(4096, Allocator.Persistent);
                _result2 = new NativeArray<RaycastHit>(4096, Allocator.Persistent);
                _entityId = new NativeArray<int>(4096, Allocator.Persistent);
                
                _alreadyStarted = true;
            }

            private void SetLodData()
            {
                var pilarSpawner = SystemAPI.GetSingleton<PillarSpawnerComponent>();
                _prefabEntity = pilarSpawner.PrefabEntity;

                LoDBakeData = new LoDData
                {
                    MeshInfoDownLod0 = EntityManager.GetComponentData<MaterialMeshInfo>(pilarSpawner.PilarDownLod0),
                    ColliderDownLod0 = EntityManager.GetComponentData<PhysicsCollider>(pilarSpawner.PilarDownLod0),
            
                    MeshInfoDownLod1 = EntityManager.GetComponentData<MaterialMeshInfo>(pilarSpawner.PilarDownLod1),
                    ColliderDownLod1 = EntityManager.GetComponentData<PhysicsCollider>(pilarSpawner.PilarDownLod1),
            
                    MeshInfoUpLod0 = EntityManager.GetComponentData<MaterialMeshInfo>(pilarSpawner.PilarUpLod0),
                    ColliderUpLod0 = EntityManager.GetComponentData<PhysicsCollider>(pilarSpawner.PilarUpLod0),
            
                    MeshInfoUpLod1 = EntityManager.GetComponentData<MaterialMeshInfo>(pilarSpawner.PilarUpLod1),
                    ColliderUpLod1 = EntityManager.GetComponentData<PhysicsCollider>(pilarSpawner.PilarUpLod1),
                    
                    MeshInfoUpLod2 = EntityManager.GetComponentData<MaterialMeshInfo>(pilarSpawner.PilarUpLod2),
                    MeshInfoDownLod2 = EntityManager.GetComponentData<MaterialMeshInfo>(pilarSpawner.PilarDownLod2),
                };
            }


            protected override void OnUpdate()
            {
                if(!Enabled)return;

                if (_timeRunning >= FrequencyBandAnalyser.GetCurrentLevel().Duration) 
                    UpdateDesiredHeight();
                else
                {

                    RayCastBake();
                    
                    LodSystem();
                }
                
            }


            #endregion




        private NativeArray<RaycastCommand> _raycastCommands;
        private NativeArray<RaycastCommand> _raycastCommands2;
        private NativeArray<RaycastHit> _result;
        private NativeArray<RaycastHit> _result2;
        private NativeArray<int> _entityId;
        private void RayCastBake()
        {
            var cameraLtw = new LocalToWorld { Value = CameraTrack.Instance.camera.transform.localToWorldMatrix };
            var entityId = _entityId;
            var layermask = ~0;

            var commands = new NativeArray<RaycastCommand>(4096, Allocator.Persistent);
            var commands2 = new NativeArray<RaycastCommand>(4096, Allocator.Persistent);

            var camForward2D = cameraLtw.Forward.WithZeroY();
            camForward2D.Normalize();
            var camPos = cameraLtw.Position;
            var timeRunning = _timeRunning * _gridMakerComponent.MapTransitionSpeed;
            var GridHeight = _gridMakerComponent.GridHeight;

            //Rotate and bake Raycasts
            Entities
                .ForEach((int entityInQueryIndex, ref LocalToWorld localToWorld, ref PilarComponent pillarComponent) =>
                {
                    //--------------
                    // HeightJob
                    if (timeRunning < 2f)
                    {
                        float height;

                        if (timeRunning > 1)
                            height = pillarComponent.OldPos = pillarComponent.CurrentPos = pillarComponent.DesiredPos;
                        else
                            pillarComponent.CurrentPos = height = Mathf.Lerp(pillarComponent.OldPos, pillarComponent.DesiredPos, timeRunning);

                        localToWorld.Value.c3.y = height;
                        pillarComponent.IsHighest = !(height < GridHeight);
                    }
                    //--------------
                    
                    var dirToPillar2D = (localToWorld.Position - cameraLtw.Position).WithZeroY().normalized();
                    
                    
                    camPos.y = localToWorld.Position.y;
                    var forward = localToWorld.Forward;
                    var right = localToWorld.Right;
                    var position = localToWorld.Position;
                    
                    // First orientate all Pillars to the camera, just orientate
                  
                    // rotate towards the camera
                    if (Vector3.Dot(-dirToPillar2D, localToWorld.Forward) < 0.5)
                    {
                        localToWorld.Value.c0 = new Vector4(forward.x, 0, forward.z, 0);
                        localToWorld.Value.c2 = new Vector4(-right.x, 0, -right.z, 0);
                    }
                    // inverse the scale to match the orientation
                    localToWorld.Value.c0 = position.x < camPos.x ? new float4(1, 0, 0, 0) : new float4(-1, 0, 0, 0);
                    localToWorld.Value.c2 = position.z < camPos.z ? new float4(0, 0, 1, 0) : new float4(0, 0, -1, 0);
                    
                    
                    entityId[entityInQueryIndex] = pillarComponent.ID; // not work because the index in porallel


                    // bake the raycast
                    
                    float3 offset = default;
                    float3 offset2 = default;
          
                    
                    if(Float3.Dot(Float3.forward, camForward2D) > 0)
                        
                        
                        if(pillarComponent.IsHighest)
                        {
                            
                            offset = localToWorld.Forward * .5f -localToWorld.Up;
                            offset2 = localToWorld.Right * .5f  -localToWorld.Up;
                            //Debug
                            //Debug.DrawLine(localToWorld.Position ,localToWorld.Position + offset,  Color.cyan);
                            //Debug.DrawLine(localToWorld.Position + offset, cameraLtw.Position,  Color.blue);
                            
                            //Debug.DrawLine(localToWorld.Position ,localToWorld.Position + offset2,Color.magenta);
                            //Debug.DrawLine(localToWorld.Position + offset2, cameraLtw.Position,Color.red);
                        }
                        else
                        {
                            offset = (localToWorld.Forward + localToWorld.Right) * -.5f;

                            offset2 = Float3.Dot(localToWorld.Forward, -dirToPillar2D) > 0.5f
                                ? (localToWorld.Forward - localToWorld.Right) * .5f
                                : (localToWorld.Right - localToWorld.Forward) * .5f;
                            //Debug
                            //Debug.DrawLine(localToWorld.Position ,localToWorld.Position + offset,  Color.cyan);
                            //Debug.DrawLine(localToWorld.Position + offset, cameraLtw.Position,  Color.blue);
                            //Debug.DrawLine(localToWorld.Position ,localToWorld.Position + offset2,Color.magenta);
                            //Debug.DrawLine(localToWorld.Position + offset2, cameraLtw.Position,Color.red);
                        }
                    
                    commands[entityInQueryIndex] = BakeRaycastCommand(
                        localToWorld.Position + offset, 
                        cameraLtw.Position, layermask);
                    
                    commands2[entityInQueryIndex] = BakeRaycastCommand(
                        localToWorld.Position + offset2,
                        cameraLtw.Position, layermask);
                    
                        
                    
                    
                }).ScheduleParallel();

            Dependency = JobHandle.CombineDependencies(Dependency, RaycastCommand.ScheduleBatch( commands, _result, 1,1, Dependency));
            Dependency = JobHandle.CombineDependencies(Dependency, RaycastCommand.ScheduleBatch( commands2, _result2, 1,1, Dependency));
            Dependency.Complete();


            // At the moment dont know a better way to inverse the array            
            var joby = new InverseArrayJob
            {
                Value = entityId
            };
            joby.Schedule().Complete();
            
            _entityId = entityId;
            //_raycastCommands = commands;
            //_raycastCommands2 = commands2;
        }

        [BurstCompile]
        private partial struct InverseArrayJob: IJob
        {
            public NativeArray<int> Value;
            public void Execute()
            {
                var inverseArray = new NativeArray<int>(Value.Length, Allocator.Temp);
                for (var i = 0; i < Value.Length; i++) 
                    inverseArray[Value[i]] = i;
                Value = inverseArray;
            }
        }
        
        
        
        private static RaycastCommand BakeRaycastCommand(Vector3 pilarPos, Vector3 cameraPos, LayerMask mask)
        {
            return new RaycastCommand
            {
                direction = -(pilarPos - cameraPos).normalized,
                distance = Vector3.Distance(pilarPos, cameraPos),
                from = pilarPos,
                queryParameters = new QueryParameters
                {
                    hitBackfaces = false,
                    hitMultipleFaces = true,
                    layerMask = mask
                }
            };
        }
        

        private void LodSystem()
        {
            _timeRunning += SystemAPI.Time.fixedDeltaTime;
            
            var joby = new LodSystemJob
            {
                CameraLtw = new LocalToWorld { Value = CameraTrack.Instance.camera.transform.localToWorldMatrix },
                LODDistance = GameManager.Instance.LodDistance,
                LODBakeData = LoDBakeData,
                ResultRaycast = _result,
                ResultRaycast2 = _result2
            };
            
            joby.ScheduleParallel();
  

        }
        

        public void EnableSystem(bool active) => Enabled = _validStart = active;
        public void PauseSystem(bool active) => Enabled = active;

    


        #region PopulateCell

            private void EntityCleanUp()
            {
                var archetype = EntityManager.CreateArchetype(
                    typeof(PilarComponent),
                    typeof(LocalToWorld),
                    typeof(RenderBounds),
                    typeof(MaterialMeshInfo),
                    typeof(PhysicsCollider),
                    typeof(PhysicsWorldIndex),
                    typeof(RenderFilterSettings),
                    typeof(RenderMeshArray)
                );

                var entity = EntityManager.CreateEntity(archetype);


                EntityManager.SetComponentData(entity, EntityManager.GetComponentData<PilarComponent>(_prefabEntity));
                EntityManager.SetComponentData(entity, EntityManager.GetComponentData<LocalToWorld>(_prefabEntity));


                EntityManager.SetComponentData(entity, new RenderBounds
                {
                    Value = EntityManager.GetComponentData<RenderBounds>(_prefabEntity).Value
                });

                EntityManager.SetComponentData(entity, new PhysicsCollider
                {
                    Value = EntityManager.GetComponentData<PhysicsCollider>(_prefabEntity).Value
                });



                var meshInfo = EntityManager.GetComponentData<MaterialMeshInfo>(_prefabEntity);
                EntityManager.SetComponentData(entity, meshInfo);
                
                
                EntityManager.SetComponentData(entity, EntityManager.GetComponentData<PhysicsCollider>(_prefabEntity));

                EntityManager.SetSharedComponent(entity, EntityManager.GetSharedComponent<PhysicsWorldIndex>(_prefabEntity));
                EntityManager.SetSharedComponent(entity, EntityManager.GetSharedComponent<RenderFilterSettings>(_prefabEntity));
                EntityManager.SetSharedComponentManaged(entity, EntityManager.GetSharedComponentManaged<RenderMeshArray>(_prefabEntity));

                FrequencyBandAnalyser.Instance.boxyMat =
                    EntityManager.GetSharedComponentManaged<RenderMeshArray>(_prefabEntity).GetMaterial(meshInfo);
                
                
                EntityManager.AddComponent<WorldToLocal_Tag>(entity);
                EntityManager.AddComponent<PerInstanceCullingTag>(entity);
                EntityManager.RemoveComponent<Simulate>(entity);

                
                EntityManager.DestroyEntity(_prefabEntity);
                _prefabEntity = entity;
            }
            private void PopulateCell(Vector2Int trimCords, int height)
            {
                var fraction = height / _gridMakerComponent.CellAmount;

                
                for (var x = fraction * trimCords.x; x < fraction * (trimCords.x + 1); x++)
                    for (var z = fraction * trimCords.y; z < fraction * (trimCords.y + 1); z++)
                    {
                        var offset = x % 2 != 0 ? Vector3.zero : new Vector3(0, 0, GridOffset);
                        var pilarPos = new Vector3(x, 0, z) + offset + _startPos;

                        _allEntities.Add(CreatePilarEntity(new int2(x, z), pilarPos, ref _prefabEntity));
                    }

            }
            
            private static int GetIndex(int x, int y, int height) => x * height + y;

            private int _entityIndex;
            private Entity CreatePilarEntity(int2 pilarCord, float3 position, ref Entity prefab)
            {
                
                var entity = EntityManager.Instantiate(prefab);

                EntityManager.SetComponentData(entity, 
                    new LocalToWorld
                    {
                        Value = Matrix4x4.TRS(position, Quaternion.identity, Vector3.one)
                    });

                
                EntityManager.SetComponentData(entity, 
                    new PilarComponent
                    {
                        DesiredPos = 0,
                        Cords = pilarCord,
                        IsHighest = false,
                        ID = _entityIndex
                        
                    });
                _entityIndex++;
                return entity;
            }

        #endregion

        
        
        private void UpdateDesiredHeight()
        {
            _timeRunning = 0;

            new UpdateDesiredJob
            {
                Texture = FrequencyBandAnalyser.GetCurrentLevel().GetNextLevel(),
                GridHeight = _gridMakerComponent.GridHeight,
            }.Run();

            GridManager2D.Instance.UpdateValidNodes(FrequencyBandAnalyser.GetCurrentLevel().GetCurrentLevel());
            SysAgent.Instance.UpdatePathJobsLevel();
        }




        [BurstCompile]
        private partial struct UpdateDesiredJob : IJobEntity
        {
            public NativeArray<float> Texture;
            public float GridHeight;

            private void Execute(ref PilarComponent pilarComponent)
            {
                var index = GetIndex(pilarComponent.Cords.x, pilarComponent.Cords.y, 64);
                pilarComponent.DesiredPos = Texture[index] * GridHeight;
                pilarComponent.OldPos = pilarComponent.CurrentPos;
                pilarComponent.IsHighest = Texture[index] > 0;
            }
        }
        
        
        /*
         
         [ReadOnly] public CollisionWorld collisionWorld;
                [ReadOnly] public EntityManager entityManager;
        if (dist > lodDistance.y && !pilar.IsHighest && !RayCastToCamera(localToWorld.Position, cameraLtw.Position,
            ref collisionWorld,
            ref entityManager))
        {

            renderBounds = new RenderBounds
            {
                Value = new AABB
                {
                    Center = new float3(0, 200, 0),
                    Extents = new float3(.5f, 2.5f, .5f)
                }
            };
            return;
        }*/
        
        
    
    
            [BurstCompile]
            private partial struct LodSystemJob : IJobEntity
            {
                public LocalToWorld CameraLtw;
                public Vector2 LODDistance;
                public LoDData LODBakeData;
                public NativeArray<RaycastHit> ResultRaycast;
                public NativeArray<RaycastHit> ResultRaycast2;


                private void Execute( ref LocalToWorld localToWorld, ref PilarComponent pilar, ref MaterialMeshInfo materialMeshInfo, ref PhysicsCollider physicsCollider, ref RenderBounds renderBounds)
                {

                
                
                
                
                var dist = Vector3.Distance(CameraLtw.Position, localToWorld.Position);
                var dirToPilar = localToWorld.Position - CameraLtw.Position;
                
                if (Vector3.Angle(CameraLtw.Forward, dirToPilar) > 45) return;
                
                var camPos = CameraLtw.Position;
  
                

                // Up
                if (localToWorld.Value.c3.y > 0)
                {
                    
                    renderBounds = new RenderBounds
                    {
                        Value = new AABB
                        {
                            Center = new float3(0,-2.5f,0),
                            Extents = new float3(.5f,2.5f,.5f)
                        }
                    };
                    
                    
                    if (dist < LODDistance.x)
                        materialMeshInfo = LODBakeData.MeshInfoUpLod0;
                    else if (dist < LODDistance.y)
                        materialMeshInfo = LODBakeData.MeshInfoUpLod1;
                    else
                        materialMeshInfo = LODBakeData.MeshInfoUpLod2;
     
                }
                // Down
                else
                {
                    
                    renderBounds = new RenderBounds
                    {
                        Value = new AABB
                        {
                            Center = new float3(0,0,0),
                            Extents = new float3(.5f,.1f,.5f)
                        }
                    };
                    if (dist < LODDistance.x)
                        materialMeshInfo = LODBakeData.MeshInfoDownLod0;
                    else //if (dist < lodDistance.y)
                        materialMeshInfo = LODBakeData.MeshInfoDownLod1;
                    //else
                        //materialMeshInfo = lodBakeData.MeshInfoDownLod2;
                    //
                    var absPos = CameraLtw.Position;
                    absPos.y = localToWorld.Position.y;
                    var dirToCam2D = (absPos - localToWorld.Position);

                    
                }

                }
            }
            
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        private static readonly PhysicsCategoryTags LevelCategory = new() { Category00 = true };
        private static readonly PhysicsCategoryTags AgentCategory = new() { Category02 = true };
        
        private static bool RayCastToCamera(Vector3 start, Vector3 end, ref CollisionWorld collisionWorld, ref EntityManager entityManager)
        {
            //end.y = start.y += .5f;

            var colFilter = new CollisionFilter {
                BelongsTo = AgentCategory.Value,
                CollidesWith = LevelCategory.Value,
                GroupIndex = 0
            };
            
            //----
//

            var nya = new Vector3(
                start.x < end.x ? -.49f : .49f,
                0.1f,
                start.z < end.z ? -.49f : .49f); 

            
            var rayInput = new RaycastInput {
                Start = start + nya,
                End = end,
                Filter = colFilter
            };
            collisionWorld.CastRay(rayInput, out var hit);
            Debug.DrawLine(start + nya, end, Color.red);
            return !entityManager.HasComponent<PilarComponent>(hit.Entity);
            ////
        }
        
    }
}