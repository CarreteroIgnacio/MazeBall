using System;
using Unity.Entities;
using UnityEngine;

namespace Level
{

    public class AuthPilarSpawner : MonoBehaviour
    {
        public GameObject prefab;
        public GameObject pilarDownLod0;
        public GameObject pilarDownLod1;
        public GameObject pilarDownLod2;
        public GameObject pilarUpLod0;
        public GameObject pilarUpLod1;
        public GameObject pilarUpLod2;
        public GameObject rampCollider;
    }

    public class PilarSpawnerBaker : Baker<AuthPilarSpawner>
    {
        [Obsolete("Obsolete")]
        public override void Bake(AuthPilarSpawner authoring)
        {
            AddComponent( new PillarSpawnerComponent
            {
                PrefabEntity = GetEntity(authoring.prefab),
                PilarDownLod0 = GetEntity(authoring.pilarDownLod0),
                PilarDownLod1 = GetEntity(authoring.pilarDownLod1),
                PilarDownLod2 = GetEntity(authoring.pilarDownLod2),
                PilarUpLod0 = GetEntity(authoring.pilarUpLod0),
                PilarUpLod1 = GetEntity(authoring.pilarUpLod1),
                PilarUpLod2 = GetEntity(authoring.pilarUpLod2),
            });
        }
    }
    
}