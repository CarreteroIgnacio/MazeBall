using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Physics.Custom.EditModeTests")]
